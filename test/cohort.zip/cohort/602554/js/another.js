function hello() {
  console.log('hello there, howre you?');
}

function goodbye() {
  var directory = this;
  console.log('goodbye');
}