function init() {
  console.log('done');
}