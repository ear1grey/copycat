function hi() {
  console.log('hi there, are you okay?');
}

function goodbye() {
  var dir = this;
  console.log('goodbye');
}