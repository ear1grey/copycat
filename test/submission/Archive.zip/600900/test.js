function hello() {
  var hi = 'true';
}